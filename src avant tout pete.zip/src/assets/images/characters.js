import adelineImage from './Adeline.jpeg';

// Exportons directement l'image
export const adeline = adelineImage;

export default {
  adeline: adelineImage
};
