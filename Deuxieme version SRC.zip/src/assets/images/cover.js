// Importation de l'image de couverture
const coverImage = '/assets/images/book-covers/couverture1.jpg';  // Chemin public vers l'image

export { coverImage };
